READ ME:
This is the Landing page made by group 7 in 1st semester multimediadesign in Erhvervsakemi Aarhus

members:
Annamaria Sommer
Anton Reedtz Nesgaard
Benjamin Stistrup Skov Knudsen
Ida Thomassen
Lærke Theodine Lønne
